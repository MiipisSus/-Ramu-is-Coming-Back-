﻿
namespace Tester
{
    partial class Form_MAIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_MAIN));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Calender = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.Schedule = new System.Windows.Forms.ImageList(this.components);
            this.Purchase = new System.Windows.Forms.ImageList(this.components);
            this.Option = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.Character = new System.Windows.Forms.PictureBox();
            this.Ramu01 = new System.Windows.Forms.ImageList(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Ramu02 = new System.Windows.Forms.ImageList(this.components);
            this.Ramu03 = new System.Windows.Forms.ImageList(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.Clothes = new System.Windows.Forms.ImageList(this.components);
            this.HideFrame = new System.Windows.Forms.Timer(this.components);
            this.HideFrameTime = new System.Windows.Forms.Timer(this.components);
            this.imageList2 = new System.Windows.Forms.ImageList(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.ShowDialogFrame = new System.Windows.Forms.Timer(this.components);
            this.Ramu01_EUp = new System.Windows.Forms.ImageList(this.components);
            this.Ramu02_EUp = new System.Windows.Forms.ImageList(this.components);
            this.Ramu03_EUp = new System.Windows.Forms.ImageList(this.components);
            this.Animation = new System.Windows.Forms.Timer(this.components);
            this.Ramu01_ECL = new System.Windows.Forms.ImageList(this.components);
            this.Ramu02_ECL = new System.Windows.Forms.ImageList(this.components);
            this.Ramu03_ECL = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Character)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tester.Properties.Resources.MAINFORM;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Calender
            // 
            this.Calender.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Calender.ImageStream")));
            this.Calender.TransparentColor = System.Drawing.Color.Transparent;
            this.Calender.Images.SetKeyName(0, "CALENDER.png");
            this.Calender.Images.SetKeyName(1, "CALENDER_MouseMove.png");
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(250, 215);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            this.pictureBox2.MouseLeave += new System.EventHandler(this.pictureBox2_MouseLeave);
            this.pictureBox2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox2_MouseMove);
            // 
            // Schedule
            // 
            this.Schedule.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Schedule.ImageStream")));
            this.Schedule.TransparentColor = System.Drawing.Color.Transparent;
            this.Schedule.Images.SetKeyName(0, "SCHEDULE.png");
            this.Schedule.Images.SetKeyName(1, "SCHEDULE_MouseMove.png");
            // 
            // Purchase
            // 
            this.Purchase.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Purchase.ImageStream")));
            this.Purchase.TransparentColor = System.Drawing.Color.Transparent;
            this.Purchase.Images.SetKeyName(0, "PURCHASE.png");
            this.Purchase.Images.SetKeyName(1, "PURCHASE_MouseMove.png");
            // 
            // Option
            // 
            this.Option.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Option.ImageStream")));
            this.Option.TransparentColor = System.Drawing.Color.Transparent;
            this.Option.Images.SetKeyName(0, "OPTION.png");
            this.Option.Images.SetKeyName(1, "OPTION_MouseMove.png");
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Location = new System.Drawing.Point(440, 140);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(200, 145);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 2;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            this.pictureBox4.MouseLeave += new System.EventHandler(this.pictureBox4_MouseLeave);
            this.pictureBox4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox4_MouseMove);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Location = new System.Drawing.Point(440, 0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(200, 145);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            this.pictureBox3.MouseLeave += new System.EventHandler(this.pictureBox3_MouseLeave);
            this.pictureBox3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox3_MouseMove);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Location = new System.Drawing.Point(440, 285);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(200, 150);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            this.pictureBox5.MouseLeave += new System.EventHandler(this.pictureBox5_MouseLeave);
            this.pictureBox5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox5_MouseMove);
            // 
            // Character
            // 
            this.Character.BackColor = System.Drawing.Color.Transparent;
            this.Character.Location = new System.Drawing.Point(28, 252);
            this.Character.Name = "Character";
            this.Character.Size = new System.Drawing.Size(362, 368);
            this.Character.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Character.TabIndex = 5;
            this.Character.TabStop = false;
            this.Character.Click += new System.EventHandler(this.Character_Click);
            // 
            // Ramu01
            // 
            this.Ramu01.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu01.ImageStream")));
            this.Ramu01.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu01.Images.SetKeyName(0, "Red01.png");
            this.Ramu01.Images.SetKeyName(1, "Blue01.png");
            this.Ramu01.Images.SetKeyName(2, "Green01.png");
            this.Ramu01.Images.SetKeyName(3, "Yellow01.png");
            this.Ramu01.Images.SetKeyName(4, "Purple01.png");
            this.Ramu01.Images.SetKeyName(5, "Pink01.png");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 25F);
            this.label1.Location = new System.Drawing.Point(5, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 45);
            this.label1.TabIndex = 6;
            this.label1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 25F);
            this.label2.Location = new System.Drawing.Point(115, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 45);
            this.label2.TabIndex = 7;
            this.label2.Text = "0";
            // 
            // Ramu02
            // 
            this.Ramu02.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu02.ImageStream")));
            this.Ramu02.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu02.Images.SetKeyName(0, "Red02.png");
            this.Ramu02.Images.SetKeyName(1, "Blue02.png");
            this.Ramu02.Images.SetKeyName(2, "Green02.png");
            this.Ramu02.Images.SetKeyName(3, "Yellow02.png");
            this.Ramu02.Images.SetKeyName(4, "Purple02.png");
            this.Ramu02.Images.SetKeyName(5, "Pink02.png");
            // 
            // Ramu03
            // 
            this.Ramu03.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu03.ImageStream")));
            this.Ramu03.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu03.Images.SetKeyName(0, "Red03.png");
            this.Ramu03.Images.SetKeyName(1, "Blue03.png");
            this.Ramu03.Images.SetKeyName(2, "Green03.png");
            this.Ramu03.Images.SetKeyName(3, "Yellow03.png");
            this.Ramu03.Images.SetKeyName(4, "Purple03.png");
            this.Ramu03.Images.SetKeyName(5, "Pink03.png");
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "MAINFORM.png");
            // 
            // Clothes
            // 
            this.Clothes.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Clothes.ImageStream")));
            this.Clothes.TransparentColor = System.Drawing.Color.Transparent;
            this.Clothes.Images.SetKeyName(0, "babysuit.png");
            this.Clothes.Images.SetKeyName(1, "catear.png");
            this.Clothes.Images.SetKeyName(2, "coolglass.png");
            this.Clothes.Images.SetKeyName(3, "flower.png");
            this.Clothes.Images.SetKeyName(4, "hat.png");
            this.Clothes.Images.SetKeyName(5, "ties.png");
            // 
            // HideFrame
            // 
            this.HideFrame.Interval = 10;
            this.HideFrame.Tick += new System.EventHandler(this.HideFrame_Tick);
            // 
            // HideFrameTime
            // 
            this.HideFrameTime.Interval = 1000;
            this.HideFrameTime.Tick += new System.EventHandler(this.HideFrameTime_Tick);
            // 
            // imageList2
            // 
            this.imageList2.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList2.ImageStream")));
            this.imageList2.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList2.Images.SetKeyName(0, "DialogFrame.png");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.label3.Location = new System.Drawing.Point(50, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 27);
            this.label3.TabIndex = 9;
            this.label3.Text = "label3";
            // 
            // ShowDialogFrame
            // 
            this.ShowDialogFrame.Interval = 2000;
            this.ShowDialogFrame.Tick += new System.EventHandler(this.ShowDialogFrame_Tick);
            // 
            // Ramu01_EUp
            // 
            this.Ramu01_EUp.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu01_EUp.ImageStream")));
            this.Ramu01_EUp.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu01_EUp.Images.SetKeyName(0, "Red01_EyesUp.png");
            this.Ramu01_EUp.Images.SetKeyName(1, "Blue01_EyesUp.png");
            this.Ramu01_EUp.Images.SetKeyName(2, "Green01_EyesUp.png");
            this.Ramu01_EUp.Images.SetKeyName(3, "Yellow01_EyesUp.png");
            this.Ramu01_EUp.Images.SetKeyName(4, "Purple01_EyesUp.png");
            this.Ramu01_EUp.Images.SetKeyName(5, "Pink01_EyesUp.png");
            // 
            // Ramu02_EUp
            // 
            this.Ramu02_EUp.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu02_EUp.ImageStream")));
            this.Ramu02_EUp.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu02_EUp.Images.SetKeyName(0, "Red02_EyesUp.png");
            this.Ramu02_EUp.Images.SetKeyName(1, "Blue02_EyesUp.png");
            this.Ramu02_EUp.Images.SetKeyName(2, "Green02_EyesUp.png");
            this.Ramu02_EUp.Images.SetKeyName(3, "Yellow02_EyesUp.png");
            this.Ramu02_EUp.Images.SetKeyName(4, "Purple02_EyesUp.png");
            this.Ramu02_EUp.Images.SetKeyName(5, "Pink02_EyesUp.png");
            // 
            // Ramu03_EUp
            // 
            this.Ramu03_EUp.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu03_EUp.ImageStream")));
            this.Ramu03_EUp.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu03_EUp.Images.SetKeyName(0, "Red03_EyesUp.png");
            this.Ramu03_EUp.Images.SetKeyName(1, "Blue03_EyesUp.png");
            this.Ramu03_EUp.Images.SetKeyName(2, "Green03_EyesUp.png");
            this.Ramu03_EUp.Images.SetKeyName(3, "Yellow03_EyesUp.png");
            this.Ramu03_EUp.Images.SetKeyName(4, "Purple03_EyesUp.png");
            this.Ramu03_EUp.Images.SetKeyName(5, "Pink03_EyesUp.png");
            // 
            // Animation
            // 
            this.Animation.Interval = 250;
            this.Animation.Tick += new System.EventHandler(this.Animation_Tick);
            // 
            // Ramu01_ECL
            // 
            this.Ramu01_ECL.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu01_ECL.ImageStream")));
            this.Ramu01_ECL.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu01_ECL.Images.SetKeyName(0, "Red01_EyesClosed.png");
            this.Ramu01_ECL.Images.SetKeyName(1, "Blue01_EyesClosed.png");
            this.Ramu01_ECL.Images.SetKeyName(2, "Green01_EyesClosed.png");
            this.Ramu01_ECL.Images.SetKeyName(3, "Yellow01_EyesClosed.png");
            this.Ramu01_ECL.Images.SetKeyName(4, "Purple01_EyesClosed.png");
            this.Ramu01_ECL.Images.SetKeyName(5, "Pink01_EyesClosed.png");
            // 
            // Ramu02_ECL
            // 
            this.Ramu02_ECL.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu02_ECL.ImageStream")));
            this.Ramu02_ECL.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu02_ECL.Images.SetKeyName(0, "Red02_EyesClosed.png");
            this.Ramu02_ECL.Images.SetKeyName(1, "Blue02_EyesClosed.png");
            this.Ramu02_ECL.Images.SetKeyName(2, "Green02_EyesClosed.png");
            this.Ramu02_ECL.Images.SetKeyName(3, "Yellow02_EyesClosed.png");
            this.Ramu02_ECL.Images.SetKeyName(4, "Purple02_EyesClosed.png");
            this.Ramu02_ECL.Images.SetKeyName(5, "Pink02_EyesClosed.png");
            // 
            // Ramu03_ECL
            // 
            this.Ramu03_ECL.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu03_ECL.ImageStream")));
            this.Ramu03_ECL.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu03_ECL.Images.SetKeyName(0, "Red03_EyesClosed.png");
            this.Ramu03_ECL.Images.SetKeyName(1, "Blue03_EyesClosed.png");
            this.Ramu03_ECL.Images.SetKeyName(2, "Green03_EyesClosed.png");
            this.Ramu03_ECL.Images.SetKeyName(3, "Yellow03_EyesClosed.png");
            this.Ramu03_ECL.Images.SetKeyName(4, "Purple03_EyesClosed.png");
            this.Ramu03_ECL.Images.SetKeyName(5, "Pink03_EyesClosed.png");
            // 
            // Form_MAIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 641);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Character);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_MAIN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form_MAIN";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Character)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ImageList Calender;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ImageList Schedule;
        private System.Windows.Forms.ImageList Purchase;
        private System.Windows.Forms.ImageList Option;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox Character;
        private System.Windows.Forms.ImageList Ramu01;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ImageList Ramu02;
        private System.Windows.Forms.ImageList Ramu03;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ImageList Clothes;
        private System.Windows.Forms.Timer HideFrame;
        private System.Windows.Forms.Timer HideFrameTime;
        private System.Windows.Forms.ImageList imageList2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Timer ShowDialogFrame;
        private System.Windows.Forms.ImageList Ramu01_EUp;
        private System.Windows.Forms.ImageList Ramu02_EUp;
        private System.Windows.Forms.ImageList Ramu03_EUp;
        private System.Windows.Forms.Timer Animation;
        private System.Windows.Forms.ImageList Ramu01_ECL;
        private System.Windows.Forms.ImageList Ramu02_ECL;
        private System.Windows.Forms.ImageList Ramu03_ECL;
    }
}