﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_MAIN : Form
    {
        /*回到MAIN時需Check事項:
         * 年齡(更換拉姆型態)
         * 生病(是否達成生病事件條件)
         * 死亡(是否生病天數超過5周)
         * 破產(是否負金錢天數超過5周)
         * 結局(是否年齡==3歲)
         */
        int range = 0;
        bool Animation_EyesClosed = false;
        Random rdn = new Random(Guid.NewGuid().GetHashCode());
        String[] talk = { "早安，" + Property.my_name + "！", "今天早上吃甚麼？", "好想睡覺喔......", "肚子餓了～", Property.my_name + "，你最近過得好嗎？" };
        String[] ConditionalTalk = { Property.my_name + "......我生病了......", "我們是不是沒錢了，" + Property.my_name + "？", "最近特別累，壓力太大了，好想休息喔......" };
        public Form_MAIN()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            ChangeDate();
            pictureBox2.Image = Calender.Images[0];
            pictureBox3.Image = Schedule.Images[0];
            pictureBox4.Image = Purchase.Images[0];
            pictureBox5.Image = Option.Images[0];
            this.Character.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            this.pictureBox5.Parent = this.pictureBox1;
            label3.Visible = false;
            label3.Text = "哈囉！";
            RepaintSprite(0);
            //衣服測試
            //Overlap(new Bitmap(Clothes.Images[0]));
            CheckEverything();
            Animation.Start();

        }
        private void ChangeDate()
        {
            label1.Text = Property.date[0].ToString();
            label2.Text = Property.date[1].ToString();
        }
        private void CheckEverything()
        {
            ChangeDate();
            CheckAge();
            CheckSick();
            CheckMoney();
            CheckEnd();
        }
        private void CheckAge()
        {
            //Ending條件
            if(Property.age==3)
            {
                if (Property.power >= 150 && Property.intelligence >= 150 && Property.creativity >= 150 && Property.charm >= 150 && Property.morality >= 150)
                    Property.Ending = 1;
                else if (Property.creativity >= 170 && Property.morality >= 170)
                    Property.Ending = 2;
                else if (Property.physics >= 300 && Property.power >= 150)
                    Property.Ending = 3;
                else if (Property.charm >= 150 && Property.morality >= 200)
                    Property.Ending = 4;
                else if (Property.intelligence >= 200 && Property.creativity >= 100)
                    Property.Ending = 5;
                else if (Property.intelligence >= 150 && Property.charm >= 170)
                    Property.Ending = 6;
                else
                    Property.Ending = 7;
            }
        }
        private void CheckSick()
        {
            if(Property.physics>=Property.pressure)
            {
                Property.Sick = false;
                Property.Sick_count = 0;
                return;
            }
            if(Property.Sick_count==5)
            {
                Property.Ending = 8;
                return;
            }
            if (Property.Sick)
            {
                Property.Sick_count++;
            }
            if(Property.Sick_count==3)
            {
                Form_NOTICE FN = new Form_NOTICE(1);
                FN.ShowDialog();
            }
            if (Property.physics < Property.pressure && Property.Sick_count == 0)
            {
                Property.Sick = true;
                Form_NOTICE FN = new Form_NOTICE(0);
                FN.ShowDialog();
            }
        }
        private void CheckMoney()
        {
            if(Property.money>=0)
            {
                Property.noMoney_count = 0;
                Property.noMoney = false;
                return;
            }
            if (Property.noMoney_count == 5)
            {
                Property.Ending = 9;
                return;
            }
            if (Property.noMoney)
            {
                Property.noMoney_count++;
            }
            if (Property.noMoney_count == 3)
            {
                Form_NOTICE FN = new Form_NOTICE(4);
                FN.ShowDialog();
            }
            if (Property.money < 0 && Property.noMoney_count == 0)
            {
                Property.noMoney = true;
                Form_NOTICE FN = new Form_NOTICE(3);
                FN.ShowDialog();
            }
        }
        private void CheckEnd()
        {
            if(Property.Ending!=0)
            {
                Animation.Stop();
                this.DialogResult = DialogResult.Cancel;
                this.Enabled = false;
                HideFrame.Start();
                HideFrameTime.Start();
            }
        }
        private void RepaintSprite(int Dialog_flag)
        {
            Bitmap bm = new Bitmap(362, 368);
            Bitmap image;
            Bitmap h;
            Graphics g;
            //改變拉姆圖像
            if(Dialog_flag==1)
            {
                switch (Property.age)
                {
                    case 0:
                        image = new Bitmap(Ramu01_EUp.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                    case 1:
                        image = new Bitmap(Ramu02_EUp.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                    case 2:
                    case 3:
                        image = new Bitmap(Ramu03_EUp.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                }
            }
            else
            {
                switch (Property.age)
                {
                    case 0:
                        image = new Bitmap((Animation_EyesClosed) ? Ramu01_ECL.Images[Property.color] : Ramu01.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                    case 1:
                        image = new Bitmap((Animation_EyesClosed) ? Ramu02_ECL.Images[Property.color] : Ramu02.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                    case 2:
                    case 3:
                        image = new Bitmap((Animation_EyesClosed) ? Ramu03_ECL.Images[Property.color] : Ramu03.Images[Property.color]);
                        h = new Bitmap(bm);
                        g = Graphics.FromImage(h);
                        g.DrawImage(image, 0, 0, 362, 368);
                        bm = h;
                        break;
                }
            }
            //改變拉姆服裝
            if (Property.Clothe_id != 0)
            {
                image = new Bitmap(Clothes.Images[Property.Clothe_id - 1]);
                h = new Bitmap(bm);
                g = Graphics.FromImage(h);
                g.DrawImage(image, 0, 0, 362, 368);
                bm = h;
            }
            //對話框
            if(Dialog_flag==1)
            {
                image = new Bitmap(imageList2.Images[0]);
                h = new Bitmap(bm);
                g = Graphics.FromImage(h);
                g.DrawImage(image, 0, 0, 271, 184);
                bm = h;
            }
            Character.Image = bm;
        }
        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = Calender.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = Calender.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = Schedule.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox4.Image = Purchase.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox5.Image = Option.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = Schedule.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Image = Purchase.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            pictureBox5.Image = Option.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Animation.Stop();
            Form_SCHEDULE fSCH = new Form_SCHEDULE();
            fSCH.ShowDialog();
            CheckEverything();
            if(this.DialogResult!=DialogResult.Cancel)
            {
                Animation.Start();
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form_INFORMATION FIM = new Form_INFORMATION();
            FIM.ShowDialog();
        }

        private void Form_MAIN_FormClosing(object sender, FormClosingEventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void HideFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0)
            {
                this.Opacity -= 0.02;
            }
        }

        private void HideFrameTime_Tick(object sender, EventArgs e)
        {
            Form_ENDING FED = new Form_ENDING();
            HideFrameTime.Stop();
            HideFrame.Stop();
            this.Close();
            FED.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Animation.Stop();
            Form_SETTINGS FST = new Form_SETTINGS();
            FST.ShowDialog();
            if(FST.DialogResult==DialogResult.OK||FST.DialogResult==DialogResult.Cancel)
            {
                CheckEverything();
                Animation.Start();
            }
            else if(FST.DialogResult==DialogResult.Yes)
            {
                Form_TITLE FT = new Form_TITLE();
                FT.Show();
                this.Close();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Animation.Stop();
            Form_CHOOSECLOTHES FCC = new Form_CHOOSECLOTHES();
            FCC.ShowDialog();
            Animation.Start();
        }

        private void Character_Click(object sender, EventArgs e)
        {
            Animation.Stop();
            RandomTalk();
            label3.Visible = true;
            RepaintSprite(1);
            ShowDialogFrame.Start();
        }

        private void ShowDialogFrame_Tick(object sender, EventArgs e)
        {
            label3.Visible = false;
            RepaintSprite(0);
            ShowDialogFrame.Stop();
            Animation.Start();
        }

        private void Animation_Tick(object sender, EventArgs e)
        {
            range = rdn.Next(8);
            if (range > 0)//1~7
                Animation_EyesClosed = false;
            else
                Animation_EyesClosed = true;
            RepaintSprite(0);
        }
        private void RandomTalk()
        {
            if (Property.Sick)
                label3.Text = ConditionalTalk[0];
            else if (Property.noMoney)
                label3.Text = ConditionalTalk[1];
            else if (Property.pressure > Property.physics - 10)
                label3.Text = ConditionalTalk[2];
            else
            {
                range = rdn.Next(5);
                label3.Text = talk[range];
            }
        }
    }
}
