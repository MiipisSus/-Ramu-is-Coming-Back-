﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_SCHEDULE : Form
    {
        int kind = 0;int item_chosen_Count = 0;
        int[] item_chosen = new int[4];
        List<String> Work_Label = new List<string>();
        List<String> Study_Label = new List<string>();
        List<String> Activity_Label = new List<string>();
        List<String> Adventure_Label = new List<string>();
        List<Label> Display_Label = new List<Label>();
        List<PictureBox> Display_right = new List<PictureBox>();
        List<PictureBox> Display_left = new List<PictureBox>();

        public Form_SCHEDULE()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            Display_right.Add(pictureBox7);
            Display_right.Add(pictureBox8);
            Display_right.Add(pictureBox9);
            Display_right.Add(pictureBox10);
            Display_right.Add(pictureBox11);
            Display_right.Add(pictureBox12);
            Display_left.Add(pictureBox13);
            Display_left.Add(pictureBox14);
            Display_left.Add(pictureBox15);
            Display_left.Add(pictureBox16);
            Display_Label.Add(label2);
            Display_Label.Add(label3);
            Display_Label.Add(label4);
            Display_Label.Add(label5);
            Display_Label.Add(label6);
            Display_Label.Add(label7);
            pictureBox2.Image = Enter.Images[0];
            pictureBox3.Image = Work.Images[0];
            pictureBox4.Image = Study.Images[0];
            pictureBox5.Image = Activity.Images[0];
            pictureBox6.Image = Adventure.Images[0];
            pictureBox17.Image = Cancel.Images[0];
            Work_Label.Add("清潔工");
            Work_Label.Add("服務生");
            Work_Label.Add("照顧植物");
            Work_Label.Add("搬運工");
            Work_Label.Add("助教");
            Work_Label.Add("烘焙助手");
            Study_Label.Add("拳擊課");
            Study_Label.Add("美術課");
            Study_Label.Add("禮儀課");
            Study_Label.Add("讀書課");
            Study_Label.Add("倫理課");
            Activity_Label.Add("玩球");
            Activity_Label.Add("玩益智拼圖");
            Activity_Label.Add("跳舞");
            Adventure_Label.Add("去教堂");
            Adventure_Label.Add("去醫院");
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            label4.Text = "";
            label5.Text = "";
            label6.Text = "";
            label7.Text = "";
            this.label1.Parent = this.pictureBox1;
            this.label2.Parent = this.pictureBox1;
            this.label3.Parent = this.pictureBox1;
            this.label4.Parent = this.pictureBox1;
            this.label5.Parent = this.pictureBox1;
            this.label6.Parent = this.pictureBox1;
            this.label7.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            this.pictureBox5.Parent = this.pictureBox1;
            this.pictureBox6.Parent = this.pictureBox1;
            this.pictureBox7.Parent = this.pictureBox1;
            this.pictureBox8.Parent = this.pictureBox1;
            this.pictureBox9.Parent = this.pictureBox1;
            this.pictureBox10.Parent = this.pictureBox1;
            this.pictureBox11.Parent = this.pictureBox1;
            this.pictureBox12.Parent = this.pictureBox1;
            this.pictureBox13.Parent = this.pictureBox1;
            this.pictureBox14.Parent = this.pictureBox1;
            this.pictureBox15.Parent = this.pictureBox1;
            this.pictureBox16.Parent = this.pictureBox1;
            this.pictureBox17.Parent = this.pictureBox1;
            SwitchBoxImage();
        }
        private void SwitchBoxImage()//當行程種類(kind)改變時，切換顯示活動圖示
        {
            int i;
            for(i=0;i<6;i++)
            {
                //初始化
                Display_right[i].Image=null;
                Display_Label[i].Text = "";
            }
            switch(kind)
            {
                case 0:
                    for(i=0;i<Work_Item.Images.Count;i++)
                    {
                        Display_Label[i].Text = Work_Label[i];
                        Display_right[i].Image = Work_Item.Images[i];
                    }
                    break;
                case 1:
                    for(i=0;i<Study_Item.Images.Count;i++)
                    {
                        Display_Label[i].Text = Study_Label[i];
                        Display_right[i].Image = Study_Item.Images[i];
                    }
                    break;
                case 2:
                    for (i = 0; i < Activity_Item.Images.Count; i++)
                    {
                        Display_Label[i].Text = Activity_Label[i];
                        Display_right[i].Image = Activity_Item.Images[i];
                    }
                    break;
                case 3:
                    for (i = 0; i < Adventure_Item.Images.Count; i++)
                    {
                        Display_Label[i].Text = Adventure_Label[i];
                        Display_right[i].Image = Adventure_Item.Images[i];
                    }
                    break;
            }
        }
        private void ChangeLeftListImage(int box)
        {
            //直接抽出Display_right的圖片進行更換
            Display_left[item_chosen_Count - 1].Image = Display_right[box].Image;
        }
        private void CancelChosenItem(int box)
        {
            int i;
            if (item_chosen_Count <= box) 
                return;
            label1.Text = "已取消ID : " + item_chosen[box] + " 的行程";
            for (i = box; i < item_chosen_Count - 1; i++)
            {
                item_chosen[i] = item_chosen[i + 1];
                Display_left[i].Image = Display_left[i + 1].Image;
            }
            Display_left[item_chosen_Count - 1].Image = null;
            item_chosen[item_chosen_Count - 1] = -1;
            item_chosen_Count--;
        }
        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = Enter.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = Enter.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = Work.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = Work.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox4.Image = Study.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Image = Study.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox5.Image = Activity.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            pictureBox5.Image = Activity.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox6_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox6.Image = Adventure.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {
            pictureBox6.Image = Adventure.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox7_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox7_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox8_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox8_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox9_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox9_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox13_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox13_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox14_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox14_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox15_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox15_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox16_MouseMove(object sender, MouseEventArgs e)
        {
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox16_MouseLeave(object sender, EventArgs e)
        {
            this.Cursor = Cursors.Default;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            kind = 0;
            SwitchBoxImage();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            kind = 1;
            SwitchBoxImage();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if (item_chosen_Count == 4 )
            {
                label1.Text = "行程已滿！";
                return;
            }
            else if(pictureBox7.Image == null)
            {
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "1");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(0);
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if (item_chosen_Count == 4 || pictureBox8.Image == null)
            {
                label1.Text = "行程已滿！";
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "2");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(1);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if(item_chosen_Count==4||pictureBox9.Image==null)
            {
                label1.Text = "行程已滿！";
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "3");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(2);
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            CancelChosenItem(0);
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            CancelChosenItem(1);
        }

        private void pictureBox15_Click(object sender, EventArgs e)
        {
            CancelChosenItem(2);
        }

        private void pictureBox16_Click(object sender, EventArgs e)
        {
            CancelChosenItem(3);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (item_chosen_Count < 4)
            {
                label1.Text = "請選擇完每週行程！";
                return;
            }
            label1.Text = "行程確認！";
            //跳轉數值變動畫面
            Form_SCHDULE_PROCESS FSP = new Form_SCHDULE_PROCESS(item_chosen);
            FSP.ShowDialog();
            Close();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            kind = 2;
            SwitchBoxImage();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            kind = 3;
            SwitchBoxImage();
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if (item_chosen_Count == 4 || pictureBox9.Image == null)
            {
                label1.Text = "行程已滿！";
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "4");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(3);
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if (item_chosen_Count == 4 || pictureBox9.Image == null)
            {
                label1.Text = "行程已滿！";
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "5");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(4);
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            //item_chosen變數增加,item_chosen_count++
            //[ID] 01~06=工作,11~16=學習,21~26=娛樂,31~36=外出
            if (item_chosen_Count == 4 || pictureBox9.Image == null)
            {
                label1.Text = "行程已滿！";
                return;
            }
            item_chosen[item_chosen_Count] = Convert.ToInt32(kind.ToString() + "6");
            label1.Text = "已選擇行程ID : " + item_chosen[item_chosen_Count].ToString();
            item_chosen_Count++;
            ChangeLeftListImage(5);
        }

        private void pictureBox17_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox17_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox17.Image = Cancel.Images[1];
        }

        private void pictureBox17_MouseLeave(object sender, EventArgs e)
        {
            pictureBox17.Image = Cancel.Images[0];
        }
    }
}
