﻿
namespace Tester
{
    partial class Form_SCHDULE_PROCESS
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_SCHDULE_PROCESS));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Work = new System.Windows.Forms.ImageList(this.components);
            this.Study = new System.Windows.Forms.ImageList(this.components);
            this.Activity = new System.Windows.Forms.ImageList(this.components);
            this.Adventure = new System.Windows.Forms.ImageList(this.components);
            this.birthday_ramu = new System.Windows.Forms.ImageList(this.components);
            this.birthday_mine = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tester.Properties.Resources.SCHDULEFORM_PROCESS;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(218, 83);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(190, 190);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.textBox1.Location = new System.Drawing.Point(59, 407);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(524, 190);
            this.textBox1.TabIndex = 2;
            this.textBox1.TabStop = false;
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            this.textBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.label1.Location = new System.Drawing.Point(32, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 27);
            this.label1.TabIndex = 3;
            this.label1.Text = "label1";
            // 
            // Work
            // 
            this.Work.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Work.ImageStream")));
            this.Work.TransparentColor = System.Drawing.Color.Transparent;
            this.Work.Images.SetKeyName(0, "SCHEDULE_ITEMS_clean.png");
            this.Work.Images.SetKeyName(1, "SCHEDULE_ITEMS_server.png");
            this.Work.Images.SetKeyName(2, "SCHEDULE_ITEMS_Farm.png");
            this.Work.Images.SetKeyName(3, "SCHEDULE_ITEMS_Porter.png");
            this.Work.Images.SetKeyName(4, "SCHEDULE_ITEMS_Teacher.png");
            this.Work.Images.SetKeyName(5, "SCHEDULE_ITEMS_Baker.png");
            // 
            // Study
            // 
            this.Study.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Study.ImageStream")));
            this.Study.TransparentColor = System.Drawing.Color.Transparent;
            this.Study.Images.SetKeyName(0, "SCHEDULE_ITEMS_powerClass.png");
            this.Study.Images.SetKeyName(1, "SCHEDULE_ITEMS_artClass.png");
            this.Study.Images.SetKeyName(2, "SCHEDULE_ITEMS_charmClass.png");
            this.Study.Images.SetKeyName(3, "SCHEDULE_ITEMS_ReadClass.png");
            this.Study.Images.SetKeyName(4, "SCHEDULE_ITEMS_MoralClass.png");
            // 
            // Activity
            // 
            this.Activity.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Activity.ImageStream")));
            this.Activity.TransparentColor = System.Drawing.Color.Transparent;
            this.Activity.Images.SetKeyName(0, "SCHEDULE_ITEMS_PlayingBall.png");
            this.Activity.Images.SetKeyName(1, "SCHEDULE_ITEMS_PlayingJigsaw.png");
            this.Activity.Images.SetKeyName(2, "SCHEDULE_ITEMS_Dancing.png");
            // 
            // Adventure
            // 
            this.Adventure.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Adventure.ImageStream")));
            this.Adventure.TransparentColor = System.Drawing.Color.Transparent;
            this.Adventure.Images.SetKeyName(0, "SCHEDULE_ITEMS_Church.png");
            this.Adventure.Images.SetKeyName(1, "SCHEDULE_ITEMS_Hospital.png");
            // 
            // birthday_ramu
            // 
            this.birthday_ramu.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("birthday_ramu.ImageStream")));
            this.birthday_ramu.TransparentColor = System.Drawing.Color.Transparent;
            this.birthday_ramu.Images.SetKeyName(0, "Red_birthday.png");
            this.birthday_ramu.Images.SetKeyName(1, "Blue_birthday.png");
            this.birthday_ramu.Images.SetKeyName(2, "Green_birthday.png");
            this.birthday_ramu.Images.SetKeyName(3, "Yellow_birthday.png");
            this.birthday_ramu.Images.SetKeyName(4, "Purple_birthday.png");
            this.birthday_ramu.Images.SetKeyName(5, "Pink_birthday.png");
            // 
            // birthday_mine
            // 
            this.birthday_mine.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("birthday_mine.ImageStream")));
            this.birthday_mine.TransparentColor = System.Drawing.Color.Transparent;
            this.birthday_mine.Images.SetKeyName(0, "Red_myBirthday.png");
            this.birthday_mine.Images.SetKeyName(1, "Blue_myBirthday.png");
            this.birthday_mine.Images.SetKeyName(2, "Green_myBirthday.png");
            this.birthday_mine.Images.SetKeyName(3, "Yellow_myBirthday.png");
            this.birthday_mine.Images.SetKeyName(4, "Purple_myBirthday.png");
            this.birthday_mine.Images.SetKeyName(5, "Pink_myBirthday.png");
            // 
            // Form_SCHDULE_PROCESS
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 641);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_SCHDULE_PROCESS";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form_SCHDULE_PROCESS";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList Work;
        private System.Windows.Forms.ImageList Study;
        private System.Windows.Forms.ImageList Activity;
        private System.Windows.Forms.ImageList Adventure;
        private System.Windows.Forms.ImageList birthday_ramu;
        private System.Windows.Forms.ImageList birthday_mine;
    }
}