﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_SETTINGS : Form
    {
        public Form_SETTINGS()
        {
            InitializeComponent();
            CenterToScreen();
            pictureBox2.Image = imageList1.Images[0];
            pictureBox3.Image = imageList2.Images[0];
            pictureBox4.Image = imageList3.Images[0];
            pictureBox5.Image = Cancel.Images[0];
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            this.pictureBox5.Parent = this.pictureBox1;
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = imageList1.Images[1];
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = imageList1.Images[0];
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = imageList2.Images[1];
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = imageList2.Images[0];
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox4.Image = imageList3.Images[1];
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Image = imageList3.Images[0];
        }

        private void pictureBox5_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox5.Image = Cancel.Images[1];
        }

        private void pictureBox5_MouseLeave(object sender, EventArgs e)
        {
            pictureBox5.Image = Cancel.Images[0];
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.None;
            this.Close();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form_LODEFILE FL = new Form_LODEFILE(1);
            FL.ShowDialog();
            if (FL.DialogResult == DialogResult.OK)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void Form_SETTINGS_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Form_LODEFILE FL = new Form_LODEFILE(2);
            FL.ShowDialog();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Form_NOTICE2 FN2 = new Form_NOTICE2(2);
            FN2.ShowDialog();
            if (FN2.DialogResult == DialogResult.Yes)
            {
                this.DialogResult = DialogResult.Yes;
                this.Close();
            }
            else if (FN2.DialogResult == DialogResult.No)
                return;
        }
    }
}
