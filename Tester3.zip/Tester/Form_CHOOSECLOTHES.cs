﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_CHOOSECLOTHES : Form
    {
        public Form_CHOOSECLOTHES()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            this.pictureBox5.Parent = this.pictureBox1;
            this.pictureBox6.Parent = this.pictureBox1;
            this.pictureBox7.Parent = this.pictureBox1;
            this.pictureBox8.Parent = this.pictureBox1;
            this.pictureBox9.Parent = this.pictureBox1;
            this.label1.Parent = this.pictureBox1;
            pictureBox8.Image = Cancel.Images[0];
            pictureBox9.Image = imageList1.Images[0];
            label1.Text = "";
        }

        private void pictureBox9_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox9.Image = imageList1.Images[1];
        }

        private void pictureBox9_MouseLeave(object sender, EventArgs e)
        {
            pictureBox9.Image = imageList1.Images[0];
        }

        private void pictureBox8_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox8.Image = Cancel.Images[1];
        }

        private void pictureBox8_MouseLeave(object sender, EventArgs e)
        {
            pictureBox8.Image = Cancel.Images[0];
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 1;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 2;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 3;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 4;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 5;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 6;
            label1.Text = "成功更換服裝！";
            timer1.Start();
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            Property.Clothe_id = 0;
            label1.Text = "成功卸除服裝！";
            timer1.Start();
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = "";
        }
    }
}
