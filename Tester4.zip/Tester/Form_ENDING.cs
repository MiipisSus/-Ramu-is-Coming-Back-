﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Tester
{
    public partial class Form_ENDING : Form
    {
        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);

        String str;
        String[] Alltext = { "日子很快就過去了，我的"+Property.Ramu_name+"也逐漸長大成人", "一天早晨，我發現"+Property.Ramu_name+"不見蹤影，只看到桌上留下了一封信......"
                ,"至敬愛的"+Property.my_name+"，謝謝你一直以來的照顧，我想離家去出發尋找自己的夢想，如果我成功了會回來找你的，來日再見！"
                ,"又過了好幾年，我第一次收到了我家"+Property.Ramu_name+"的消息......"};
        String[] Endtext_1 = {"最近拉姆王國召開了一次國王徵選，以此鼓勵各地的優秀青年參與","而"+Property.Ramu_name+"正是候選人之一",
            "最後，"+Property.Ramu_name+"成功當選下一屆拉姆國國王！！"
                ,"可喜可賀，可喜可賀","明天就是"+Property.Ramu_name+"回來探望我的日子，我非常的想念它，等不及要見到它了"};
        String[] Endtext_2 = { Property.Ramu_name + "成功成為皇室聘用藝術家！", "可喜可賀，可喜可賀", "明天就是" + Property.Ramu_name + "回來探望我的日子，我非常的想念它，等不及要見到它了" };
        String[] Endtext_3 = { Property.Ramu_name + "成功成為皇家騎士！", "可喜可賀，可喜可賀", "明天就是" + Property.Ramu_name + "回來探望我的日子，我非常的想念它，等不及要見到它了" };
        String[] Endtext_4 = { Property.Ramu_name + "成功成為大神父！", "可喜可賀，可喜可賀", "明天就是" + Property.Ramu_name + "回來探望我的日子，我非常的想念它，等不及要見到它了" };
        String[] Endtext_5 = { Property.Ramu_name + "成功成為首席學者！", "可喜可賀，可喜可賀", "明天就是" + Property.Ramu_name + "回來探望我的日子，我非常的想念它，等不及要見到它了" };
        String[] Endtext_6 = { Property.Ramu_name + "成功成為商團領導人！", "可喜可賀，可喜可賀", "明天就是" + Property.Ramu_name + "回來探望我的日子，我非常的想念它，等不及要見到它了" };
        String[] EndText_7 = {Property.Ramu_name+"如今仍在外地努力經營，儘管不是十分驚人的成績，卻也足夠證明了"+Property.Ramu_name+"能夠獨立自主的能力"
                ,"明天就是"+Property.Ramu_name+"回來探望我的日子，我非常的想念它，等不及要見到它了"};
        String[] EndText_8 = { Property.Ramu_name + "因為你長期的疏忽照料，在今天的早晨離開了人世", "由於你的不負責任", "拉姆國決定永久沒收你的居住證明，並將你趕出了拉姆國", "How poor you" };
        String[] EndText_9 = {"你已經有一段時間沒有還清欠款了","因此，拉姆國只好回收了你的房子","由於你失去了飼養"+Property.Ramu_name+"的能力，收容所帶走了它"
                ,"而你流離失所了好一段時間，最後只好離開拉姆國另尋出路","How poor you"};
        int index = 0;
        int currentText = 0;
        bool startDialog = false, endDialog = false;
        public Form_ENDING()
        {
            InitializeComponent();
            this.Opacity = 0;
            this.Location = new Point(640, 210);
            ShowFrame.Start();
            ShowFrameTime.Start();
            this.Enabled = false;
            this.pictureBox2.Parent = this.pictureBox1;
            textBox1.GotFocus += textBox1_GotFocus;
            textBox1.MouseDown += textBox1_MouseDown;
        }
        private void DisplayText()
        {
            timer1.Stop();
            textBox1.Text = str;
            index = 0;
        }
        private void PaintEndCG()
        {
            Bitmap bm = new Bitmap(640, 300);
            Bitmap image;
            Bitmap h;
            Graphics g;
            image = new Bitmap(imageList1.Images[1]);
            h = new Bitmap(bm);
            g = Graphics.FromImage(h);
            g.DrawImage(image, 0, 0, 640,300);
            bm = h;
            image = new Bitmap(Ramu03.Images[Property.color]);
            h = new Bitmap(bm);
            g = Graphics.FromImage(h);
            g.DrawImage(image, 220, 85, 181, 184);
            bm = h;
            if(Property.Ending<=6)
            {
                image = new Bitmap(End_clothes.Images[Property.Ending - 1]);
                h = new Bitmap(bm);
                g = Graphics.FromImage(h);
                g.DrawImage(image, 220, 85, 181, 184);
                bm = h;
            }           
            pictureBox2.Image = bm;
        }
        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }

        private void textBox1_GotFocus(object sender, EventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (index < str.Length)
            {
                textBox1.Text += str[index];
                index += 1;
            }
            else
            {
                if (index == str.Length)
                {
                    index = 0;
                    timer1.Stop();
                }
            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (endDialog)
            {
                HideFrame.Start();
                HideFrameTime.Start();
                return;
            }
            if (currentText >= Alltext.Length && !startDialog) 
            {
                startDialog = true;
                PaintEndCG();
                currentText = 0;
                switch(Property.Ending)
                {
                    case 1:
                        Alltext = Endtext_1;
                        break;
                    case 2:
                        Alltext = Endtext_2;
                        break;
                    case 3:
                        Alltext = Endtext_3;
                        break;
                    case 4:
                        Alltext = Endtext_4;
                        break;
                    case 5:
                        Alltext = Endtext_5;
                        break;
                    case 6:
                        Alltext = Endtext_6;
                        break;
                    case 7:
                        Alltext = EndText_7;
                        break;
                    case 8:
                    case 9:
                        endDialog = true;
                        break;
                }
            }
            if (currentText >= Alltext.Length && startDialog)
            {
                endDialog = true;
                DisplayText();
                return;
            }
            if (timer1.Enabled == true)
            {
                DisplayText();
            }
            else
            {
                TexttoStr();
                textBox1.Text = "";
                timer1.Start();
            }
        }

        private void ShowFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity <= 1)
            {
                this.Opacity += 0.02;
            }
        }
        private void TexttoStr()
        {
            if (currentText == 0 && Property.Ending == 8)
            {
                Alltext = EndText_8;
                pictureBox2.Image = imageList1.Images[2];
                startDialog = true;
            }
            if (currentText == 0 && Property.Ending == 9)
            {
                Alltext = EndText_9;
                pictureBox2.Image = imageList1.Images[2];
                startDialog = true;
            }
            if (currentText == 2 && !startDialog && Property.Ending < 8) 
                pictureBox2.Image = imageList1.Images[0];
            if (currentText == 3 && !startDialog && Property.Ending < 8) 
                pictureBox2.Image = null;
            str = Alltext[currentText];
            currentText++;
        }

        private void HideFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity >= 0)
            {
                this.Opacity -= 0.02;
            }
        }

        private void HideFrameTime_Tick(object sender, EventArgs e)
        {
            Form_EndAnimmation FEA = new Form_EndAnimmation();
            HideFrameTime.Stop();
            HideFrame.Stop();
            FEA.Show();
            this.Close();
           
        }

        private void ShowFrameTime_Tick(object sender, EventArgs e)
        {
            ShowFrame.Stop();
            ShowFrameTime.Stop();
            this.Enabled = true;
            TexttoStr();
            timer1.Start();
        }
    }
}
