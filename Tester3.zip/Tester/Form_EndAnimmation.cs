﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_EndAnimmation : Form
    {
        int current = 0;
        public Form_EndAnimmation()
        {
            InitializeComponent();
            this.Opacity = 0;
            this.Location = new Point(640, 210);
            if (current == 0)
            {
                pictureBox1.Image = Image.FromFile("..\\..\\assets\\End01.png");
                current++;
            }
            ShowFrame.Start();
            ShowFrameTime.Start();
            this.Enabled = false;
        }

        private void ShowFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity <= 1)
            {
                this.Opacity += 0.02;
            }
        }

        private void ShowFrameTime_Tick(object sender, EventArgs e)
        {
            ShowFrame.Stop();
            ShowFrameTime.Stop();
            timer1.Start();
            this.Enabled = true;
        }

        private void HideFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity <= 1)
            {
                this.Opacity -= 0.02;
            }
        }

        private void HideFrameTime_Tick(object sender, EventArgs e)
        {
            HideFrame.Stop();
            HideFrameTime.Stop();
            if(current==1)
            {
                pictureBox1.Image = Image.FromFile("..\\..\\assets\\End02.png");
                current++;
                ShowFrame.Start();
                ShowFrameTime.Start();
            }
            else
            {
                Form_TITLE FT = new Form_TITLE();
                FT.Show();
                this.Close();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            HideFrame.Start();
            HideFrameTime.Start();
            timer1.Stop();
        }
    }
}
