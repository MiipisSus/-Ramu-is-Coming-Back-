﻿
namespace Tester
{
    partial class Form_EndAnimmation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_EndAnimmation));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ShowFrame = new System.Windows.Forms.Timer(this.components);
            this.ShowFrameTime = new System.Windows.Forms.Timer(this.components);
            this.HideFrame = new System.Windows.Forms.Timer(this.components);
            this.HideFrameTime = new System.Windows.Forms.Timer(this.components);
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ShowFrame
            // 
            this.ShowFrame.Interval = 10;
            this.ShowFrame.Tick += new System.EventHandler(this.ShowFrame_Tick);
            // 
            // ShowFrameTime
            // 
            this.ShowFrameTime.Interval = 1000;
            this.ShowFrameTime.Tick += new System.EventHandler(this.ShowFrameTime_Tick);
            // 
            // HideFrame
            // 
            this.HideFrame.Interval = 10;
            this.HideFrame.Tick += new System.EventHandler(this.HideFrame_Tick);
            // 
            // HideFrameTime
            // 
            this.HideFrameTime.Interval = 1000;
            this.HideFrameTime.Tick += new System.EventHandler(this.HideFrameTime_Tick);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "End01.png");
            this.imageList1.Images.SetKeyName(1, "End02.png");
            // 
            // timer1
            // 
            this.timer1.Interval = 2500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form_EndAnimmation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(640, 640);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_EndAnimmation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form_EndAnimmation";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer ShowFrame;
        private System.Windows.Forms.Timer ShowFrameTime;
        private System.Windows.Forms.Timer HideFrame;
        private System.Windows.Forms.Timer HideFrameTime;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Timer timer1;
    }
}