﻿
namespace Tester
{
    partial class Form_GROWINGUP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_GROWINGUP));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Ramu02 = new System.Windows.Forms.ImageList(this.components);
            this.Ramu03 = new System.Windows.Forms.ImageList(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::Tester.Properties.Resources.GROWINGUP;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(178, 192);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(275, 307);
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.label1.Location = new System.Drawing.Point(173, 538);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 27);
            this.label1.TabIndex = 2;
            this.label1.Text = "label1";
            // 
            // Ramu02
            // 
            this.Ramu02.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu02.ImageStream")));
            this.Ramu02.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu02.Images.SetKeyName(0, "Red02.png");
            this.Ramu02.Images.SetKeyName(1, "Blue02.png");
            this.Ramu02.Images.SetKeyName(2, "Green02.png");
            this.Ramu02.Images.SetKeyName(3, "Yellow02.png");
            this.Ramu02.Images.SetKeyName(4, "Purple02.png");
            this.Ramu02.Images.SetKeyName(5, "Pink02.png");
            // 
            // Ramu03
            // 
            this.Ramu03.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu03.ImageStream")));
            this.Ramu03.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu03.Images.SetKeyName(0, "Red03.png");
            this.Ramu03.Images.SetKeyName(1, "Blue03.png");
            this.Ramu03.Images.SetKeyName(2, "Green03.png");
            this.Ramu03.Images.SetKeyName(3, "Yellow03.png");
            this.Ramu03.Images.SetKeyName(4, "Purple03.png");
            this.Ramu03.Images.SetKeyName(5, "Pink03.png");
            // 
            // Form_GROWINGUP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 641);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_GROWINGUP";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form_GROWINGUP";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList Ramu02;
        private System.Windows.Forms.ImageList Ramu03;
    }
}