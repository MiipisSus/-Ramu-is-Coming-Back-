﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_IDENTITYCARD : Form
    {
        bool Correct = true;
        String error;
        String notice = "名字限制10個字以內\r\n生日限制輸入數字";
        public Form_IDENTITYCARD()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            this.label1.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            label1.Text = "姓名限制10個字以內\r\n生日限制輸入數字";
            pictureBox2.Image = imageList1.Images[0];
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = imageList1.Images[1];
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = imageList1.Images[0];
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar)&&!Char.IsControl(e.KeyChar)){ e.Handled = true; }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !Char.IsControl(e.KeyChar)) { e.Handled = true; }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Correct = true;
            if(textBox1.Text==String.Empty||textBox1.Text.Length>=10)
            {
                error += "名字格式輸入錯誤！\r\n";
                Correct = false;
            }
            if(textBox2.Text == String.Empty || Convert.ToInt32(textBox2.Text)<1||Convert.ToInt32(textBox2.Text)>12)
            {
                error += "生日格式輸入錯誤！\r\n";
                Correct = false;
            }
            else if (textBox3.Text == String.Empty || Convert.ToInt32(textBox3.Text) < 1 || Convert.ToInt32(textBox3.Text) > 31)
            {
                error += "生日格式輸入錯誤！\r\n";
                Correct = false;
            }
            if(Correct)
            {
                Property.my_name = textBox1.Text.ToString();
                Property.my_birthday[0] = Convert.ToInt32(textBox2.Text);
                Property.my_birthday[1] = Convert.ToInt32(textBox3.Text);
                Close();
            }
            label1.Text = error;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = notice;
            error = null;
        }
    }
}
