﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;

namespace Tester
{
    static class Property
    {
        //所有屬性變數
        static public SoundPlayer Click_effects = new SoundPlayer();
        static public string my_name="測試主人";
        static public string Ramu_name="測試拉姆";
        static public int[] my_birthday = { 1, 1 };
        static public int[] ramu_birthday = { 1, 1 };//月,日
        static public int[] date = { 21, 1 };//年,月
        static public int age = 2;
        static public int color = 0;
        static public int power = 0;
        static public int intelligence = 0;
        static public int creativity = 0;
        static public int charm = 0;
        static public int physics = 50;
        static public int pressure = 100;
        static public int morality = 0;
        static public int money = 200;
        //生病
        static public bool Sick = false;
        static public int Sick_count = 0;
        //破產
        static public bool noMoney = false;
        static public int noMoney_count = 0;
        //結局
        static public int Ending = 0;//1:國王 2:藝術家 3:騎士 4:神父 5:學者 6:領袖家 7:自由職業 8:病死 9:破產
        //服裝
        static public int Clothe_id = 5;//1:寶寶裝 2:貓耳 3:酷酷眼鏡 4:花嫁 5:高禮帽 6:蝴蝶結
        static public bool[] Clothe_get = { false,false,false,false,false,false};

        static public string path_TITLE = "..\\..\\music\\POL-watch-and-learn-short.wav";
        static public string path_ClickEffect = "..\\..\\music\\zapsplat_cartoon_bubble_pop_007_40279.wav";
    }
}
