﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Drawing.Drawing2D;
using Microsoft.DirectX.DirectSound;

namespace Tester
{
    public partial class Form_TITLE : Form
    {

        public Form_TITLE()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            pictureBox2.Image = Start.Images[0];
            pictureBox3.Image = Load.Images[0];
            pictureBox4.Image = Exit.Images[0];
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            Initialize();
        }
        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = Start.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = Load.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox4.Image = Exit.Images[1];
            this.Cursor = Cursors.Hand;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = Start.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = Load.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Image = Exit.Images[0];
            this.Cursor = Cursors.Default;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            HideFrame.Start();
            HideFrameTime.Start();
            
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Form_LODEFILE FLF = new Form_LODEFILE(0);
            this.TopMost = false;
            FLF.ShowDialog();
            this.Close();
                
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            System.Environment.Exit(0);
        }

        private void HideFrame_Tick(object sender, EventArgs e)
        {
            if(this.Opacity>=0)
            {
                this.Opacity -= 0.02;
            }
        }

        private void HideFrameTime_Tick(object sender, EventArgs e)
        {
            
            HideFrame.Stop();
            Form_STARTSTORY FSS = new Form_STARTSTORY();
            HideFrameTime.Stop();
            FSS.Show();
            this.Close();
        }
        private void Initialize()
        {
            Property.age = 0;
            Property.power = 0;
            Property.intelligence = 0;
            Property.creativity = 0;
            Property.charm = 0;
            Property.physics = 50;
            Property.pressure = 0;
            Property.morality = 0;
            Property.money = 200;
            Property.Sick = false;
            Property.Sick_count = 0;
            Property.noMoney = false;
            Property.noMoney_count = 0;
            Property.Ending = 0;
            Property.Clothe_id = 0;
        }
    }
}
