﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_GROWINGUP : Form
    {
        public Form_GROWINGUP()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            this.pictureBox2.Parent = this.pictureBox1;
            this.label1.Parent = this.pictureBox1;
            switch(Property.age)
            {
                case 1:
                    pictureBox2.Image = Ramu02.Images[Property.color];
                    break;
                case 2:
                    pictureBox2.Image = Ramu03.Images[Property.color];
                    break;
            }
            label1.Text="拉姆長大了！";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
