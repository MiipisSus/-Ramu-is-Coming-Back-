﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Tester
{
    public partial class Form_STARTSTORY : Form
    {
        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);

        String[] Alltext = { "今天是我移民快樂拉姆國的日子", "我拿出我的身分證......",
            "提著行李，準備前往拉姆領養所","進門後，櫃台小姐招呼我過去，與我寒暄一番，接著將文件遞給我......","帶著我的新夥伴，等不及迎接我們未來的生活了！"};
        int index = 0;
        int currentText = 0;
        bool F1_tag = false, F2_tag = false;
        public Form_STARTSTORY()
        {
            InitializeComponent();
            this.Opacity = 0;
            this.Location = new Point(640, 210);
            ShowFrame.Start();
            ShowFrameTime.Start();
            this.Enabled = false;
            textBox1.GotFocus += textBox1_GotFocus;
            textBox1.MouseDown += textBox1_MouseDown;
        }

        private void DisplayText()
        {
            timer1.Stop();
            textBox1.Text = Alltext[currentText];
            index = 0;
            currentText++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (index < Alltext[currentText].Length)
            {
                textBox1.Text += Alltext[currentText][index];
                index += 1;
            }
            else{
                if (index == Alltext[currentText].Length)
                {
                    index = 0;
                    currentText++;
                    timer1.Stop();
                }
            }
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }
        private void textBox1_GotFocus(object sender, EventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (currentText >= Alltext.Length)
            {
                Initialize();
                Form_MAIN FM = new Form_MAIN();
                FM.Show();
                this.Close();
            }
            else if (currentText == 2&&!F1_tag)
            {
                Form_IDENTITYCARD FIC = new Form_IDENTITYCARD();
                FIC.ShowDialog();
                F1_tag = true;
                textBox1.Text = "";
                timer1.Start();
            }
            else if (currentText == 4&&!F2_tag)
            {
                Form_RAMU_IDENTITY FRI = new Form_RAMU_IDENTITY();
                FRI.ShowDialog();
                F2_tag = true;
                textBox1.Text = "";
                timer1.Start();
            }
            else if (timer1.Enabled == true)
                DisplayText();
            else
            {
                textBox1.Text = "";
                timer1.Start();
            }
        }

        private void ShowFrame_Tick(object sender, EventArgs e)
        {
            if (this.Opacity <= 1)
            {
                this.Opacity += 0.02;
            }
        }

        private void ShowFrameTime_Tick(object sender, EventArgs e)
        {
            ShowFrame.Stop();
            ShowFrameTime.Stop();
            this.Enabled = true;
            timer1.Start();
        }
        private void Initialize()
        {
            Property.age = 0;
            Property.power = 0;
            Property.intelligence = 0;
            Property.creativity = 0;
            Property.charm = 0;
            Property.physics = 50;
            Property.pressure = 0;
            Property.morality = 0;
            Property.money = 200;
            Property.Sick = false;
            Property.Sick_count = 0;
            Property.noMoney = false;
            Property.noMoney_count = 0;
            Property.Ending = 0;
            Property.Clothe_id = 0;
        }
    }
}
