﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tester
{
    public partial class Form_INFORMATION : Form
    {
        public Form_INFORMATION()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            this.label1.Parent = this.pictureBox1;
            this.label2.Parent = this.pictureBox1;
            this.label3.Parent = this.pictureBox1;
            this.label4.Parent = this.pictureBox1;
            this.label5.Parent = this.pictureBox1;
            this.label6.Parent = this.pictureBox1;
            this.label7.Parent = this.pictureBox1;
            this.label9.Parent = this.pictureBox1;
            this.label8.Parent = this.pictureBox1;
            this.label11.Parent = this.pictureBox1;
            this.label10.Parent = this.pictureBox1;
            this.label12.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            pictureBox2.Image = imageList2.Images[0];
            pictureBox4.Image = imageList1.Images[0];
            DisplayProperty();
            DisplaySprite();
        }
        private void DisplaySprite()
        {
            switch(Property.age)
            {
                case 0:
                    pictureBox3.Image = ramu01.Images[Property.color];
                    break;
                case 1:
                    pictureBox3.Image = ramu02.Images[Property.color];
                    break;
                case 2:
                    pictureBox3.Image = ramu03.Images[Property.color];
                    break;
            }
        }
        private void DisplayProperty()
        {
            label1.Text = Property.my_name;
            label2.Text = Property.my_birthday[0]+" 月 "+Property.my_birthday[1]+" 日";
            label3.Text = Property.Ramu_name;
            label4.Text = Property.ramu_birthday[0] + " 月 " + Property.ramu_birthday[1] + " 日";
            label5.Text = Property.money.ToString();
            label6.Text = Property.physics.ToString();
            label7.Text = Property.pressure.ToString();
            label8.Text = Property.power.ToString();
            label9.Text = Property.intelligence.ToString();
            label10.Text = Property.creativity.ToString();
            label11.Text = Property.charm.ToString();
            label12.Text = Property.morality.ToString();
        }
        private void pictureBox4_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox4.Image = imageList1.Images[1];
        }

        private void pictureBox4_MouseLeave(object sender, EventArgs e)
        {
            pictureBox4.Image = imageList1.Images[0];
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
