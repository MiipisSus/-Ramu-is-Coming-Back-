﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace Tester
{
    public partial class Form_RAMU_IDENTITY : Form
    {
        bool Correct = true;
        String[] color = { "紅色", "藍色", "綠色", "黃色", "紫色", "粉色" };
        String error;
        String notice = "名字限制8個字以內\r\n生日限制輸入數字";
        public Form_RAMU_IDENTITY()
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            this.label1.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            pictureBox3.Image = imageList1.Images[0];
            pictureBox2.Image = imageList2.Images[0];
            comboBox1.SelectedIndex = 0;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            pictureBox2.Image = imageList2.Images[comboBox1.SelectedIndex];
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox3.Image = imageList1.Images[1];
        }

        private void pictureBox3_MouseLeave(object sender, EventArgs e)
        {
            pictureBox3.Image = imageList1.Images[0];
        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !Char.IsControl(e.KeyChar)) { e.Handled = true; }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsNumber(e.KeyChar) && !Char.IsControl(e.KeyChar)) { e.Handled = true; }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Correct = true;
            if (textBox1.Text == String.Empty || textBox1.Text.Length >= 8)
            {
                error += "名字請輸入八個字以內！\r\n";
                Correct = false;
            }
            if (textBox2.Text == String.Empty || Convert.ToInt32(textBox2.Text) < 1 || Convert.ToInt32(textBox2.Text) > 12)
            {
                error += "生日格式輸入錯誤！\r\n";
                Correct = false;
            }
            else if (textBox3.Text == String.Empty || Convert.ToInt32(textBox2.Text) < 1 || Convert.ToInt32(textBox2.Text) > 31)
            {
                error += "生日格式輸入錯誤！\r\n";
                Correct = false;
            }
            if (Correct)
            {
                Property.Ramu_name = textBox1.Text.ToString();
                Property.ramu_birthday[0] = Convert.ToInt32(textBox2.Text);
                Property.ramu_birthday[1] = Convert.ToInt32(textBox3.Text);
                //為求遊戲平衡，遊戲開始日期為生日的下一個月
                Property.date[0] = (Property.ramu_birthday[0] != 12) ? 21 : 22;
                Property.date[1] = (Property.ramu_birthday[0] != 12) ? Property.ramu_birthday[0] + 1 : 1;
                Property.color = comboBox1.SelectedIndex;
                Close();
            }
                label1.Text = error;
                timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = notice;
            error = null;
        }
    }
}
