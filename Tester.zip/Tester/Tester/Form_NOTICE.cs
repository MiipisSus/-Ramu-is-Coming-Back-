﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Tester
{
    public partial class Form_NOTICE : Form
    {
        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);

        String[] note = { "生病了，請注意壓力值！", "已經生病很多天了\r\n,請盡快治好它", "會在三歲生日過後離開你，探索\r\n屬於自己的人生，請好好\r\n把握最後的時光。"
                , "的財產目前為負值，請注意!", "若財產繼續保持負值，\r\n將迎來遊戲結局，請注意！"};
        public Form_NOTICE(int event_id)//傳遞事件;0=生病,1=生病2,2=長大,3=破產,4=破產2
        {
            InitializeComponent();
            CenterToScreen();
            
            this.pictureBox2.Parent = this.pictureBox1;
            pictureBox2.Image = imageList1.Images[0];
            textBox1.Text = Property.Ramu_name + note[event_id];
            textBox1.GotFocus += textBox1_GotFocus;
            textBox1.MouseDown += textBox1_MouseDown;
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }

        private void textBox1_GotFocus(object sender, EventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }

        private void pictureBox2_MouseMove(object sender, MouseEventArgs e)
        {
            pictureBox2.Image = imageList1.Images[1];
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Image = imageList1.Images[0];
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
