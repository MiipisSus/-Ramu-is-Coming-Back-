﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace Tester
{
    public partial class Form_SCHDULE_PROCESS : Form
    {

        [DllImport("user32", EntryPoint = "HideCaret")]
        private static extern bool HideCaret(IntPtr hWnd);

        int[] item_chosen = new int[4];
        int current = 0;int birthday_week=0;int birthday_week2 = 0;
        bool Birthday_tag = false, Birthday_tag_2=false;
        String[] Work_Rate = { "做得很好。", "做的普普通通。", "狀況不太好，搞砸了。" };
        String[] Study_Rate = { "學習效率良好，進步迅速。", "的課程一般般的度過了", "的課程沒有好好吸收進去。" };
        String[] Activity_Rate = {"玩球玩得很開心。","一起拼拼圖。","跳舞跳得很賣力。"};
        String[] Church_Rate = { "參加了教會活動。", "洗淨了自身的罪孽。" };
        String[] Hospital_Rate = { "去了醫院。", "去了醫院看病，已經痊癒了！" };
        Random rdn = new Random(Guid.NewGuid().GetHashCode());
        int rate;
        public Form_SCHDULE_PROCESS(int[] item)
        {
            InitializeComponent();
            this.Location = new Point(640, 210);
            item_chosen = item;
            this.label1.Parent = this.pictureBox1;
            this.pictureBox2.Parent = this.pictureBox1;
            
            label1.Text = "";
            textBox1.GotFocus += textBox1_GotFocus;
            textBox1.MouseDown += textBox1_MouseDown;
            Birthday_Check();
            EveryWeek();
            current++;

        }
        private void Birthday_Check()
        {
            if(Property.date[1]==Property.ramu_birthday[0])
            {
                Birthday_tag = true;
                if (Property.ramu_birthday[1] <= 7)
                    birthday_week = 1;
                else if (Property.ramu_birthday[1] <= 14)
                    birthday_week = 2;
                else if (Property.ramu_birthday[1] <= 21)
                    birthday_week = 3;
                else if (Property.ramu_birthday[1] <= 31)
                    birthday_week = 4;
            }
            if(Property.date[1]==Property.my_birthday[0])
            {
                Birthday_tag_2 = true;
                if (Property.my_birthday[1] <= 7)
                    birthday_week2 = 1;
                else if (Property.my_birthday[1] <= 14)
                    birthday_week2 = 2;
                else if (Property.my_birthday[1] <= 21)
                    birthday_week2 = 3;
                else if (Property.my_birthday[1] <= 31)
                    birthday_week2 = 4;
            }
        }
        private int CreateRate()
        {
            int Probability;
            if (Property.Sick)//0~2一般，3~9不好
            {
                Probability = rdn.Next(10);
                if (Probability < 3)
                    return 1;
                else
                    return 2;
            }
            else//0~2很好，3~7一般，8~9不好
            {
                Probability = rdn.Next(10);
                if (Probability < 3)
                    return 0;
                else if (Probability < 8)
                    return 1;
                else
                    return 2;
            }
        }
        private void EveryWeek()
        {
            if(item_chosen[current]<10)
            {
                pictureBox2.Image = Work.Images[item_chosen[current]-1];
                textBox1.Text = "今天" + Property.Ramu_name + Work_Rate[rate] + "\r\n";
            }
            else if(item_chosen[current]<20)
            {
                pictureBox2.Image = Study.Images[item_chosen[current]-11];
                textBox1.Text = "今天" + Property.Ramu_name + Study_Rate[rate] + "\r\n";
            }
            else if(item_chosen[current]<30)
            {
                pictureBox2.Image = Activity.Images[item_chosen[current] - 21];
                textBox1.Text =Property.Ramu_name+ "今天" + Property.my_name + Activity_Rate[item_chosen[current] - 21] + "\r\n";
            }
            else
            {
                pictureBox2.Image = Adventure.Images[item_chosen[current] - 31];
            }
            rate = CreateRate();
            label1.Text = "Week " + (current + 1).ToString();
            ChangeProperty(rate);
        }
        /* 
         * 01:清潔工  02:服務生  03:照顧植物  04:搬運工  05:小老師  06:烘焙助手
         * 11:拳擊課  12:藝術課  13:禮儀課  14:讀書課  15:倫理課
         * 21:打球  22:玩益智拼圖  23:跳舞
         * 31:去教堂  32:去醫院
         */
        private void ChangeProperty(int rate)
        {
            int value;
            switch(item_chosen[current])
            {
                case 1:
                    if(rate==0)
                    {
                        value= rdn.Next(3) + 8;
                        textBox1.Text += "體力增加了" + value+"。\r\n";
                        Property.physics += value;
                        value = 5;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else if(rate==1)
                    {
                        value= rdn.Next(3) + 6;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 4;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else
                    {
                        value= rdn.Next(2) + 5;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 3;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    value = 20;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money += value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 2:
                    if(rate==0)
                    {
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 5;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                    }
                    else if(rate==1)
                    {
                        value = rdn.Next(2) + 4;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 4;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                    }
                    else
                    {
                        value = 3;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 3;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                    }
                    value = 30;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money += value;
                    value = rdn.Next(7) + 7;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 3:
                    if (rate == 0)
                    {
                        value = 3;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else if (rate == 1)
                    {
                        value = 2;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = rdn.Next(2) + 4;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = rdn.Next(2) + 5;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else
                    {
                        value = 1;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = 3;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 5;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    value = 25;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(7) + 9;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 4:
                    if (rate == 0)
                    {
                        value = rdn.Next(3) + 10;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 5;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                    }
                    else if (rate == 1)
                    {
                        value = rdn.Next(3) + 8;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 4;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                    }
                    else
                    {
                        value = 7;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 3;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                    }
                    value = 40;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money += value;
                    value = rdn.Next(3) + 14;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 5:
                    if (rate == 0)
                    {
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                        value = 3;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else if (rate == 1)
                    {
                        value = rdn.Next(2) + 5;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                        value = 2;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else
                    {
                        value = 5;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                        value = 1;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money += value;
                    value = rdn.Next(4) + 12;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 6:
                    if (rate == 0)
                    {
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else if (rate == 1)
                    {
                        value = rdn.Next(2) + 4;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = rdn.Next(2) + 5;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else
                    {
                        value = 3;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                        value = 5;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    value = 30;
                    textBox1.Text += "金錢增加了" + value + "。\r\n";
                    Property.money += value;
                    value = rdn.Next(3) + 8;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 11:
                    if(rate==0)
                    {
                        value = rdn.Next(3) + 10;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = 5;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                    }
                    else if(rate==1)
                    {
                        value = rdn.Next(2) + 8;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = 4;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                    }
                    else
                    {
                        value = 7;
                        textBox1.Text += "力量增加了" + value + "。\r\n";
                        Property.power += value;
                        value = 3;
                        textBox1.Text += "體力增加了" + value + "。\r\n";
                        Property.physics += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢減少了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 12:
                    if(rate==0)
                    {
                        value = rdn.Next(3) + 15;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else if(rate==1)
                    {
                        value = rdn.Next(3) + 13;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    else
                    {
                        value = rdn.Next(2) + 11;
                        textBox1.Text += "創意增加了" + value + "。\r\n";
                        Property.creativity += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢減少了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 13:
                    if(rate==0)
                    {
                        value = rdn.Next(3) + 10;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = 5;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else if(rate==1)
                    {
                        value = rdn.Next(3) + 8;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = 4;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else 
                    {
                        value = rdn.Next(2) + 6;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = 3;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢減少了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 14:
                    if (rate == 0)
                    {
                        value = rdn.Next(3) + 15;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                    }
                    else if (rate == 1)
                    {
                        value = rdn.Next(3) + 13;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                    }
                    else
                    {
                        value = rdn.Next(2) + 11;
                        textBox1.Text += "智慧增加了" + value + "。\r\n";
                        Property.intelligence += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢減少了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 15:
                    if (rate == 0)
                    {
                        value = 5;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = rdn.Next(3) + 10;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else if (rate == 1)
                    {
                        value = 4;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = rdn.Next(3) + 8;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    else
                    {
                        value = 3;
                        textBox1.Text += "魅力增加了" + value + "。\r\n";
                        Property.charm += value;
                        value = rdn.Next(3) + 6;
                        textBox1.Text += "道德增加了" + value + "。\r\n";
                        Property.morality += value;
                    }
                    value = 50;
                    textBox1.Text += "金錢減少了" + value + "。\r\n";
                    Property.money -= value;
                    value = rdn.Next(5) + 5;
                    textBox1.Text += "壓力增加了" + value + "。\r\n";
                    Property.pressure += value;
                    break;
                case 21:
                    value = rdn.Next(3)+1;
                    textBox1.Text += "體力增加了" + value + "。\r\n";
                    Property.physics += value;
                    value = rdn.Next(3) + 1;
                    textBox1.Text += "力量增加了" + value + "。\r\n";
                    Property.power += value;
                    value = rdn.Next(6) + 15;
                    textBox1.Text += "壓力減少了" + value + "。\r\n";
                    Property.pressure -= (Property.pressure < value) ? Property.pressure : value;
                    break;
                case 22:
                    value = rdn.Next(3) + 1;
                    textBox1.Text += "智慧增加了" + value + "。\r\n";
                    Property.intelligence += value;
                    value = rdn.Next(3) + 1;
                    textBox1.Text += "創意增加了" + value + "。\r\n";
                    Property.creativity += value;
                    value = rdn.Next(6) + 15;
                    textBox1.Text += "壓力減少了" + value + "。\r\n";
                    Property.pressure -= (Property.pressure < value) ? Property.pressure : value;
                    break;
                case 23:
                    value = rdn.Next(3) + 1;
                    textBox1.Text += "體力增加了" + value + "。\r\n";
                    Property.physics += value;
                    value = rdn.Next(3) + 1;
                    textBox1.Text += "魅力增加了" + value + "。\r\n";
                    Property.charm += value;
                    value = rdn.Next(6) + 15;
                    textBox1.Text += "壓力減少了" + value + "。\r\n";
                    Property.pressure -= (Property.pressure < value) ? Property.pressure : value;
                    break;
                case 31:
                    textBox1.Text = "今天" + Property.Ramu_name + Church_Rate[0] + "\r\n";
                    value = rdn.Next(6) + 5;
                    textBox1.Text += "道德增加了" + value + "。\r\n";
                    Property.morality += value;
                    break;
                case 32:
                    if (Property.Sick)
                    {
                        Property.Sick = false;
                        Property.Sick_count = 0;
                        textBox1.Text = "今天" + Property.Ramu_name + Hospital_Rate[1] + "\r\n";
                        Property.pressure = 0;
                        value = 200;
                        textBox1.Text += "金錢減少了" + value + "。\r\n";
                        Property.money -= value;
                    }
                    else 
                    {
                        textBox1.Text = "今天" + Property.Ramu_name + Hospital_Rate[0] + "\r\n";
                    }
                    break;



            }
        }
        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (current == birthday_week)
            {
                Property.age++;
                textBox1.Text = "今天是" + Property.Ramu_name + "的生日！";
                pictureBox2.Image = birthday_ramu.Images[Property.color];
                birthday_week = 0;
                return;
            }
            if(current==birthday_week2)
            {
                textBox1.Text = "今天是" + Property.my_name + "的生日！\r\n"+Property.Ramu_name+"送給我200塊錢！";
                Property.money += 200;
                pictureBox2.Image = birthday_mine.Images[Property.color];
                birthday_week2 = 0;
                return;
            }
            if (current == 4)
            {
                if (Birthday_tag && Property.age != 3)
                {
                    Form_GROWINGUP FGU = new Form_GROWINGUP();
                    FGU.ShowDialog();
                }
                if(Property.date[1]<12)
                    Property.date[1]++;
                else
                {
                    Property.date[0]++;
                    Property.date[1] = 1;
                }
                Close();
                return;
            }
            EveryWeek();
            current++;
        }

        private void textBox1_MouseDown(object sender, MouseEventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }
        private void textBox1_GotFocus(object sender, EventArgs e)
        {
            HideCaret((sender as TextBox).Handle);
        }
    }
}
