﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Tester
{
    public partial class Form_LODEFILE : Form
    {
        string[] data = { "..\\..\\save\\data1.txt", "..\\..\\save\\data2.txt", "..\\..\\save\\data3.txt" };
        List<Label> AllLabel = new List<Label>();
        List<PictureBox> AllPic = new List<PictureBox>();
        bool success_tag = false; int main_tag = 0;//1:load 2:save
        public Form_LODEFILE(int id)//0:load in Title 1:load in main 2:save in main
        {
            InitializeComponent();
            if (id == 1)
                main_tag = 1;
            else if (id == 2)
                main_tag = 2;
            this.Location = new Point(640, 210);
            this.pictureBox2.Parent = this.pictureBox1;
            this.pictureBox3.Parent = this.pictureBox1;
            this.pictureBox4.Parent = this.pictureBox1;
            this.pictureBox5.Parent = this.pictureBox1;
            AllLabel.Add(label1);
            AllLabel.Add(label2);
            AllLabel.Add(label3);
            AllPic.Add(pictureBox6);
            AllPic.Add(pictureBox7);
            AllPic.Add(pictureBox8);
            label1.Text = "";
            label2.Text = "";
            label3.Text = "";
            pictureBox5.Image = Cancel.Images[0];
            LoadDisplay();
        }
        private void LoadDisplay()
        {
            String path;
            StreamReader sr;
            int age, color;
            for(int i=0;i<3;i++)
            {
                path = data[i];
                sr = new StreamReader(path);
                AllLabel[i].Text = sr.ReadLine()+"\r\n";
                AllLabel[i].Text += sr.ReadLine();
                for (int j = 0; j < 6; j++)
                    sr.ReadLine();
                age = Convert.ToInt32(sr.ReadLine());
                color= Convert.ToInt32(sr.ReadLine());
                switch(age)
                {
                    case 0:
                        AllPic[i].Image = ramu01.Images[color];
                        break;
                    case 1:
                        AllPic[i].Image = ramu02.Images[color];
                        break;
                    case 2:
                        AllPic[i].Image = ramu03.Images[color];
                        break;
                }
                sr.Close();
            }
        }
        private void LoadFile(int id)
        {
            String path;
            path = data[id];
            StreamReader sw = new StreamReader(path);
            Property.my_name = sw.ReadLine();
            if (Property.my_name == null)
                return;
            Property.Ramu_name = sw.ReadLine();
            Property.my_birthday[0] = Convert.ToInt32(sw.ReadLine());
            Property.my_birthday[1] = Convert.ToInt32(sw.ReadLine());
            Property.ramu_birthday[0] = Convert.ToInt32(sw.ReadLine());
            Property.ramu_birthday[1] = Convert.ToInt32(sw.ReadLine());
            Property.date[0] = Convert.ToInt32(sw.ReadLine());
            Property.date[1] = Convert.ToInt32(sw.ReadLine());
            Property.age = Convert.ToInt32(sw.ReadLine());
            Property.color = Convert.ToInt32(sw.ReadLine());
            Property.power = Convert.ToInt32(sw.ReadLine());
            Property.intelligence = Convert.ToInt32(sw.ReadLine());
            Property.creativity = Convert.ToInt32(sw.ReadLine());
            Property.charm = Convert.ToInt32(sw.ReadLine());
            Property.physics = Convert.ToInt32(sw.ReadLine());
            Property.pressure = Convert.ToInt32(sw.ReadLine());
            Property.morality = Convert.ToInt32(sw.ReadLine());
            Property.money = Convert.ToInt32(sw.ReadLine());
            Property.Sick = (Convert.ToInt32(sw.ReadLine()) == 0) ? false : true;
            Property.Sick_count = Convert.ToInt32(sw.ReadLine());
            Property.noMoney = (Convert.ToInt32(sw.ReadLine()) == 0) ? false : true;
            Property.noMoney_count = Convert.ToInt32(sw.ReadLine());
            Property.Clothe_id = Convert.ToInt32(sw.ReadLine());
            for (int i = 0;i < 6;i++)
            {
                Property.Clothe_get[i]= (Convert.ToInt32(sw.ReadLine()) == 0) ? false : true;
            }
            success_tag = true;
            sw.Close();
            if (success_tag)
            {
                if (main_tag==1)
                {
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
                else
                {
                    Form_MAIN FM = new Form_MAIN();
                    FM.Show();
                    this.Close();
                }
            }
        }
        private void SaveFile(int id)
        {
            String path;
            path = data[id];
            StreamWriter sw = new StreamWriter(path);
            sw.WriteLine(Property.my_name);
            sw.WriteLine(Property.Ramu_name);
            sw.WriteLine(Property.my_birthday[0]);
            sw.WriteLine(Property.my_birthday[1]);
            sw.WriteLine(Property.ramu_birthday[0]);
            sw.WriteLine(Property.ramu_birthday[0]);
            sw.WriteLine(Property.date[0]);
            sw.WriteLine(Property.date[1]);
            sw.WriteLine(Property.age);
            sw.WriteLine(Property.color);
            sw.WriteLine(Property.power);
            sw.WriteLine(Property.intelligence);
            sw.WriteLine(Property.creativity);
            sw.WriteLine(Property.charm);
            sw.WriteLine(Property.physics);
            sw.WriteLine(Property.pressure);
            sw.WriteLine(Property.morality);
            sw.WriteLine(Property.money);
            sw.WriteLine((Property.Sick)?1:0);
            sw.WriteLine(Property.Sick_count);
            sw.WriteLine((Property.noMoney) ? 1 : 0);
            sw.WriteLine(Property.noMoney_count);
            sw.WriteLine(Property.Clothe_id);
            for (int i = 0; i < 6; i++)
            {
                sw.WriteLine((Property.Clothe_get[i]) ? 1 : 0);
            }
            success_tag = true;
            sw.Close();
            if(success_tag)
            {
                LoadDisplay();
            }
        }
        private void pictureBox5_MouseClick(object sender, MouseEventArgs e)
        {
            if (main_tag == 0)
            {
                Form_TITLE FT = new Form_TITLE();
                FT.Show();
            }
            this.Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (main_tag != 2)
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(0);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    LoadFile(0);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
            else
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(1);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    SaveFile(0);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (main_tag != 2)
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(0);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    LoadFile(1);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
            else
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(1);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    SaveFile(1);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (main_tag != 2)
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(0);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    LoadFile(2);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
            else
            {
                Form_NOTICE2 FN2 = new Form_NOTICE2(1);
                FN2.ShowDialog();
                if (FN2.DialogResult == DialogResult.Yes)
                    SaveFile(2);
                else if (FN2.DialogResult == DialogResult.No)
                    return;
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
