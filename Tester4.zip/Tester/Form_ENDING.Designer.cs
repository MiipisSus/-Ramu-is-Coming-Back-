﻿
namespace Tester
{
    partial class Form_ENDING
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_ENDING));
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.ShowFrame = new System.Windows.Forms.Timer(this.components);
            this.ShowFrameTime = new System.Windows.Forms.Timer(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.End_clothes = new System.Windows.Forms.ImageList(this.components);
            this.Ramu03 = new System.Windows.Forms.ImageList(this.components);
            this.HideFrame = new System.Windows.Forms.Timer(this.components);
            this.HideFrameTime = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "ENDCG2.png");
            this.imageList1.Images.SetKeyName(1, "EndCG.png");
            this.imageList1.Images.SetKeyName(2, "RAMU_DEADCG.png");
            this.imageList1.Images.SetKeyName(3, "RAMU_noMoneyCG.png");
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Tester.Properties.Resources.ENDSCENE;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 640);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Location = new System.Drawing.Point(0, 55);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(640, 300);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // ShowFrame
            // 
            this.ShowFrame.Interval = 10;
            this.ShowFrame.Tick += new System.EventHandler(this.ShowFrame_Tick);
            // 
            // ShowFrameTime
            // 
            this.ShowFrameTime.Interval = 1000;
            this.ShowFrameTime.Tick += new System.EventHandler(this.ShowFrameTime_Tick);
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.textBox1.Font = new System.Drawing.Font("微软雅黑", 15F);
            this.textBox1.Location = new System.Drawing.Point(54, 405);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(530, 192);
            this.textBox1.TabIndex = 2;
            this.textBox1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.textBox1_MouseClick);
            // 
            // timer1
            // 
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // End_clothes
            // 
            this.End_clothes.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("End_clothes.ImageStream")));
            this.End_clothes.TransparentColor = System.Drawing.Color.Transparent;
            this.End_clothes.Images.SetKeyName(0, "End_king.png");
            this.End_clothes.Images.SetKeyName(1, "End_artist.png");
            this.End_clothes.Images.SetKeyName(2, "End_soldier.png");
            this.End_clothes.Images.SetKeyName(3, "End_Godfather.png");
            this.End_clothes.Images.SetKeyName(4, "End_Scholar.png");
            this.End_clothes.Images.SetKeyName(5, "End_Leader.png");
            // 
            // Ramu03
            // 
            this.Ramu03.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("Ramu03.ImageStream")));
            this.Ramu03.TransparentColor = System.Drawing.Color.Transparent;
            this.Ramu03.Images.SetKeyName(0, "Red03.png");
            this.Ramu03.Images.SetKeyName(1, "Blue03.png");
            this.Ramu03.Images.SetKeyName(2, "Green03.png");
            this.Ramu03.Images.SetKeyName(3, "Yellow03.png");
            this.Ramu03.Images.SetKeyName(4, "Purple03.png");
            this.Ramu03.Images.SetKeyName(5, "Pink03.png");
            // 
            // HideFrame
            // 
            this.HideFrame.Interval = 10;
            this.HideFrame.Tick += new System.EventHandler(this.HideFrame_Tick);
            // 
            // HideFrameTime
            // 
            this.HideFrameTime.Interval = 1000;
            this.HideFrameTime.Tick += new System.EventHandler(this.HideFrameTime_Tick);
            // 
            // Form_ENDING
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(639, 641);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form_ENDING";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form_ENDING";
            this.TopMost = true;
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Timer ShowFrame;
        private System.Windows.Forms.Timer ShowFrameTime;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ImageList End_clothes;
        private System.Windows.Forms.ImageList Ramu03;
        private System.Windows.Forms.Timer HideFrame;
        private System.Windows.Forms.Timer HideFrameTime;
    }
}